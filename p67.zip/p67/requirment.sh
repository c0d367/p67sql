#!/bin/bash

green="\e[32m"
yellow="\e[33m"
blue="\e[34m"
red="\e[31m"
blink="\e[5m"
Normal="\e[0m"

chmod +x p67sql.sh
dpkg -s $1 &> sqlmap
if [ $? -eq 0 ]; then
    clear
    echo -e $green
    figlet p67 sql
    echo -e "\nPackage  is aldredy installed $blink [OK]$Normal"
    sleep 3
    clear
else
    echo -e "\nInstalling pakage... "
    sleep 3
    sudo apt-get install sqlmap
    sleep 3
    dpkg -s $1 &> sqlmap
    if [ $? -eq 0 ]; then
        clear
        echo -e $green
        figlet p67 sql
        echo -e "\nPackage  is  installed $blink [OK]$Normal"
        sleep 3
        clear
    else
        echo -e "somthing fishing $blink....$Normal"
    fi
fi
exit

